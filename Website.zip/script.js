console.log("Website is running smoothly without a site builder.");
